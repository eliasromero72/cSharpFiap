﻿using Microsoft.AspNetCore.Mvc;

namespace MVC_razorTagHelpers.Controllers
{
    public class ClienteController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
        public IActionResult Cadastrar()
        {
            return View();
        }
    }
}
