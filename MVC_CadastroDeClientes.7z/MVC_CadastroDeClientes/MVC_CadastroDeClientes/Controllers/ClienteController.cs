﻿using Microsoft.AspNetCore.Mvc;
using MVC_CadastroDeClientes.Models;

namespace MVC_CadastroDeClientes.Controllers
{
    public class ClienteController : Controller
    {
        //[HttpPost]
        //[HttpGet]
        public IActionResult Index()
        {
            return View();
            //return Content("Olá mundo!");
            //return RedirectToAction("Listar");
            //return new RedirectResult("https://www.google.com.br/");
        }

        //public IActionResult Cadastrar(string nome, string sobrenome)
        public IActionResult Cadastrar(Cliente cliente)
        {
            //string nome = cliente.Nome;
            //string sobrenome = cliente.Sobrenome;
            return View(cliente);
        }
    }
}
