﻿namespace MVC_CadastroDeClientes.Models
{
    public class Cliente
    {
        public string Nome { get; set; }
        public string Sobrenome { get; set; }
    }
}
